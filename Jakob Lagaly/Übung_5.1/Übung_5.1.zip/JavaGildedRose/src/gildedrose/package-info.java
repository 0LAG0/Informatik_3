/**
 * 
 */
/**
 * @author kleinen
 *
 */
package gildedrose;